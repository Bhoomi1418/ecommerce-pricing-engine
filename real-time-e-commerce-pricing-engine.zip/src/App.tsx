import { useEffect } from 'react';
import Layout from './components/Layout';
import Storefront from './components/storefront/Storefront';
import Dashboard from './components/dashboard/Dashboard';
import ABTesting from './components/abtesting/ABTesting';
import PricingEngine from './components/pricing/PricingEngine';
import FairnessTransparency from './components/fairness/FairnessTransparency';
import { useStore } from './store/useStore';

export default function App() {
  const { activeView, updateProductPrice, products } = useStore();

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly update a few product prices to simulate dynamic pricing
      const productToUpdate = products[Math.floor(Math.random() * products.length)];
      if (productToUpdate) {
        const demandMultiplier = 1 + (productToUpdate.demandScore - 0.5) * 0.1;
        const randomVariation = 0.98 + Math.random() * 0.04;
        const newPrice = Math.round(productToUpdate.basePrice * demandMultiplier * randomVariation * 100) / 100;
        
        // Apply constraints
        const minPrice = productToUpdate.basePrice * 0.85;
        const maxPrice = productToUpdate.basePrice * 1.15;
        const constrainedPrice = Math.max(minPrice, Math.min(maxPrice, newPrice));
        
        updateProductPrice(productToUpdate.id, constrainedPrice);
      }
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [products, updateProductPrice]);

  // Simulate background metrics updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Periodic update simulation - triggers analytics refresh
      // In production, this would be receiving WebSocket events from Kafka/Redis Streams
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const renderView = () => {
    switch (activeView) {
      case 'storefront':
        return <Storefront />;
      case 'dashboard':
        return <Dashboard />;
      case 'ab-testing':
        return <ABTesting />;
      case 'pricing':
        return <PricingEngine />;
      case 'fairness':
        return <FairnessTransparency />;
      default:
        return <Storefront />;
    }
  };

  return (
    <Layout>
      {renderView()}
    </Layout>
  );
}
