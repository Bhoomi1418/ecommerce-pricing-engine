import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import {
  Product,
  UserSession,
  BehavioralEvent,
  EventType,
  CartItem,
  ABTest,
  StreamEvent,
  DemandSignal,
  AnalyticsData,
  PricingRule,
  FairnessMetric
} from '../types';
import { products as initialProducts } from '../data/products';

interface AppState {
  // Products
  products: Product[];
  updateProductPrice: (productId: string, newPrice: number) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // User Session
  session: UserSession;
  trackEvent: (type: EventType, productId?: string, metadata?: Record<string, any>) => void;
  
  // Stream Events (Real-time Pipeline Simulation)
  streamEvents: StreamEvent[];
  addStreamEvent: (event: Omit<StreamEvent, 'id' | 'processed' | 'latencyMs'>) => void;
  
  // Demand Signals
  demandSignals: DemandSignal[];
  updateDemandSignal: (productId: string) => void;
  
  // A/B Tests
  abTests: ABTest[];
  createABTest: (test: Omit<ABTest, 'id'>) => void;
  updateABTestStatus: (testId: string, status: 'running' | 'completed' | 'paused') => void;
  
  // Pricing Rules
  pricingRules: PricingRule[];
  addPricingRule: (rule: Omit<PricingRule, 'id'>) => void;
  togglePricingRule: (ruleId: string) => void;
  
  // Analytics
  analytics: AnalyticsData;
  updateAnalytics: () => void;
  
  // Fairness Metrics
  fairnessMetrics: FairnessMetric[];
  
  // UI State
  selectedCategory: string | null;
  setSelectedCategory: (category: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeView: 'storefront' | 'dashboard' | 'ab-testing' | 'pricing' | 'fairness';
  setActiveView: (view: 'storefront' | 'dashboard' | 'ab-testing' | 'pricing' | 'fairness') => void;
}

const userSegments = [
  { id: 'seg_budget', name: 'Budget Conscious', willingnessToPay: 'low' as const, priceElasticity: 2.5, loyaltyScore: 0.3 },
  { id: 'seg_value', name: 'Value Seekers', willingnessToPay: 'medium' as const, priceElasticity: 1.5, loyaltyScore: 0.5 },
  { id: 'seg_premium', name: 'Premium Shoppers', willingnessToPay: 'high' as const, priceElasticity: 0.8, loyaltyScore: 0.8 },
];

const initialSession: UserSession = {
  id: uuidv4(),
  userId: `user_${Math.random().toString(36).substring(7)}`,
  startTime: Date.now(),
  events: [],
  engagementScore: 0,
  categoryAffinities: {},
  purchaseIntentProbability: 0.1,
  segment: userSegments[Math.floor(Math.random() * userSegments.length)],
  device: ['mobile', 'desktop', 'tablet'][Math.floor(Math.random() * 3)] as 'mobile' | 'desktop' | 'tablet',
  referralSource: ['organic', 'paid', 'social', 'email', 'direct'][Math.floor(Math.random() * 5)]
};

const initialABTests: ABTest[] = [
  {
    id: 'ab_001',
    name: 'Dynamic Pricing v2 vs Static',
    description: 'Testing ML-based dynamic pricing against static pricing model',
    status: 'running',
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    variants: [
      {
        id: 'control',
        name: 'Control (Static Pricing)',
        description: 'Traditional static pricing model',
        trafficPercentage: 50,
        config: { pricingModel: 'static' },
        results: {
          visitors: 15420,
          conversions: 1234,
          conversionRate: 8.0,
          revenue: 156780,
          avgOrderValue: 127.0,
          revenuePerSession: 10.16,
          confidence: 0.95
        }
      },
      {
        id: 'treatment',
        name: 'Treatment (Dynamic Pricing v2)',
        description: 'ML-based dynamic pricing with demand signals',
        trafficPercentage: 50,
        config: { pricingModel: 'dynamic_v2' },
        results: {
          visitors: 15380,
          conversions: 1456,
          conversionRate: 9.5,
          revenue: 189340,
          avgOrderValue: 130.0,
          revenuePerSession: 12.31,
          confidence: 0.97
        }
      }
    ],
    metrics: {
      totalVisitors: 30800,
      totalConversions: 2690,
      totalRevenue: 346120,
      statisticalSignificance: 0.98,
      winner: 'treatment'
    },
    targetMetric: 'revenue',
    trafficAllocation: 100
  },
  {
    id: 'ab_002',
    name: 'Session-Based Recommendations',
    description: 'Testing GRU4Rec vs Transformer-based recommendations',
    status: 'running',
    startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    variants: [
      {
        id: 'gru4rec',
        name: 'GRU4Rec Model',
        description: 'RNN-based session recommendations',
        trafficPercentage: 50,
        config: { model: 'gru4rec' },
        results: {
          visitors: 8540,
          conversions: 683,
          conversionRate: 8.0,
          revenue: 82500,
          avgOrderValue: 120.8,
          revenuePerSession: 9.66,
          confidence: 0.89
        }
      },
      {
        id: 'transformer',
        name: 'Transformer Model',
        description: 'Attention-based session recommendations',
        trafficPercentage: 50,
        config: { model: 'transformer' },
        results: {
          visitors: 8490,
          conversions: 721,
          conversionRate: 8.5,
          revenue: 89650,
          avgOrderValue: 124.3,
          revenuePerSession: 10.56,
          confidence: 0.91
        }
      }
    ],
    metrics: {
      totalVisitors: 17030,
      totalConversions: 1404,
      totalRevenue: 172150,
      statisticalSignificance: 0.87
    },
    targetMetric: 'conversionRate',
    trafficAllocation: 80
  }
];

const initialPricingRules: PricingRule[] = [
  { id: 'rule_001', name: 'High Demand Surge', type: 'demand', condition: 'demandScore > 0.8', adjustment: 10, adjustmentType: 'percentage', priority: 1, active: true, minMargin: 0.15, maxDiscount: 0.15 },
  { id: 'rule_002', name: 'Low Inventory Premium', type: 'inventory', condition: 'inventory < 20', adjustment: 8, adjustmentType: 'percentage', priority: 2, active: true, minMargin: 0.15, maxDiscount: 0.15 },
  { id: 'rule_003', name: 'Competitive Match', type: 'competition', condition: 'competitorPrice < basePrice', adjustment: -5, adjustmentType: 'percentage', priority: 3, active: true, minMargin: 0.10, maxDiscount: 0.20 },
  { id: 'rule_004', name: 'Premium Segment Pricing', type: 'segment', condition: 'segment.willingnessToPay === "high"', adjustment: 5, adjustmentType: 'percentage', priority: 4, active: false, minMargin: 0.15, maxDiscount: 0.10 },
  { id: 'rule_005', name: 'Off-Peak Discount', type: 'time', condition: 'hour >= 2 && hour <= 6', adjustment: -7, adjustmentType: 'percentage', priority: 5, active: true, minMargin: 0.12, maxDiscount: 0.20 },
];

const initialFairnessMetrics: FairnessMetric[] = [
  { segment: 'Budget Conscious', avgPriceShown: 89.50, avgDiscount: 12.5, conversionRate: 6.2, variance: 0.08, fairnessScore: 0.94 },
  { segment: 'Value Seekers', avgPriceShown: 92.30, avgDiscount: 10.2, conversionRate: 8.5, variance: 0.05, fairnessScore: 0.97 },
  { segment: 'Premium Shoppers', avgPriceShown: 95.80, avgDiscount: 8.0, conversionRate: 12.3, variance: 0.06, fairnessScore: 0.95 },
  { segment: 'New Users', avgPriceShown: 91.20, avgDiscount: 11.0, conversionRate: 5.8, variance: 0.07, fairnessScore: 0.96 },
  { segment: 'Mobile Users', avgPriceShown: 90.80, avgDiscount: 11.5, conversionRate: 7.1, variance: 0.04, fairnessScore: 0.98 },
  { segment: 'Desktop Users', avgPriceShown: 93.10, avgDiscount: 9.8, conversionRate: 9.2, variance: 0.05, fairnessScore: 0.97 },
];

export const useStore = create<AppState>((set, get) => ({
  // Products
  products: initialProducts,
  updateProductPrice: (productId, newPrice) => set((state) => ({
    products: state.products.map(p => 
      p.id === productId ? { ...p, dynamicPrice: newPrice, currentPrice: newPrice } : p
    )
  })),

  // Cart
  cart: [],
  addToCart: (product) => {
    const state = get();
    const existingItem = state.cart.find(item => item.product.id === product.id);
    
    if (existingItem) {
      set({
        cart: state.cart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      });
    } else {
      set({ cart: [...state.cart, { product, quantity: 1, priceAtAdd: product.dynamicPrice }] });
    }
    
    state.trackEvent('add_to_cart', product.id);
    state.updateDemandSignal(product.id);
  },
  removeFromCart: (productId) => {
    const state = get();
    set({ cart: state.cart.filter(item => item.product.id !== productId) });
    state.trackEvent('remove_from_cart', productId);
  },
  updateCartQuantity: (productId, quantity) => set((state) => ({
    cart: quantity > 0
      ? state.cart.map(item =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      : state.cart.filter(item => item.product.id !== productId)
  })),
  clearCart: () => set({ cart: [] }),

  // User Session
  session: initialSession,
  trackEvent: (type, productId, metadata) => {
    const state = get();
    const event: BehavioralEvent = {
      id: uuidv4(),
      timestamp: Date.now(),
      type,
      productId,
      metadata
    };
    
    const newEvents = [...state.session.events, event];
    const engagementScore = calculateEngagementScore(newEvents);
    const categoryAffinities = calculateCategoryAffinities(newEvents, state.products);
    const purchaseIntentProbability = calculatePurchaseIntent(newEvents);
    
    set({
      session: {
        ...state.session,
        events: newEvents,
        engagementScore,
        categoryAffinities,
        purchaseIntentProbability
      }
    });
    
    // Add to stream events
    state.addStreamEvent({
      timestamp: Date.now(),
      type,
      userId: state.session.userId,
      sessionId: state.session.id,
      productId,
      data: metadata || {}
    });
  },

  // Stream Events
  streamEvents: [],
  addStreamEvent: (event) => {
    const latencyMs = Math.floor(Math.random() * 50) + 5; // Simulated 5-55ms latency
    const streamEvent: StreamEvent = {
      ...event,
      id: uuidv4(),
      processed: true,
      latencyMs
    };
    
    set((state) => ({
      streamEvents: [streamEvent, ...state.streamEvents.slice(0, 99)]
    }));
    
    get().updateAnalytics();
  },

  // Demand Signals
  demandSignals: [],
  updateDemandSignal: (productId) => {
    const state = get();
    const existingSignal = state.demandSignals.find(s => s.productId === productId);
    
    if (existingSignal) {
      set({
        demandSignals: state.demandSignals.map(s =>
          s.productId === productId
            ? {
                ...s,
                viewVelocity: s.viewVelocity + 0.1,
                cartAddRate: s.cartAddRate + 0.05,
                timestamp: Date.now()
              }
            : s
        )
      });
    } else {
      set({
        demandSignals: [
          ...state.demandSignals,
          {
            productId,
            viewVelocity: 0.5,
            cartAddRate: 0.2,
            purchaseVelocity: 0,
            searchVolume: 0,
            timestamp: Date.now()
          }
        ]
      });
    }
  },

  // A/B Tests
  abTests: initialABTests,
  createABTest: (test) => set((state) => ({
    abTests: [...state.abTests, { ...test, id: `ab_${Date.now()}` }]
  })),
  updateABTestStatus: (testId, status) => set((state) => ({
    abTests: state.abTests.map(t => t.id === testId ? { ...t, status } : t)
  })),

  // Pricing Rules
  pricingRules: initialPricingRules,
  addPricingRule: (rule) => set((state) => ({
    pricingRules: [...state.pricingRules, { ...rule, id: `rule_${Date.now()}` }]
  })),
  togglePricingRule: (ruleId) => set((state) => ({
    pricingRules: state.pricingRules.map(r => 
      r.id === ruleId ? { ...r, active: !r.active } : r
    )
  })),

  // Analytics
  analytics: {
    revenueUplift: 18.7,
    recommendationHitRate: 0.342,
    ndcg: 0.78,
    p99Latency: 142,
    avgLatency: 28,
    eventsProcessed: 1247853,
    activeUsers: 3421,
    conversionRate: 8.7,
    avgOrderValue: 127.50
  },
  updateAnalytics: () => set((state) => {
    const eventsCount = state.streamEvents.length;
    const avgLatency = eventsCount > 0
      ? state.streamEvents.reduce((sum, e) => sum + e.latencyMs, 0) / eventsCount
      : 28;
    
    return {
      analytics: {
        ...state.analytics,
        eventsProcessed: state.analytics.eventsProcessed + 1,
        avgLatency: Math.round(avgLatency),
        p99Latency: Math.max(...state.streamEvents.slice(0, 100).map(e => e.latencyMs), 142)
      }
    };
  }),

  // Fairness Metrics
  fairnessMetrics: initialFairnessMetrics,

  // UI State
  selectedCategory: null,
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  activeView: 'storefront',
  setActiveView: (view) => set({ activeView: view }),
}));

// Helper functions
function calculateEngagementScore(events: BehavioralEvent[]): number {
  const weights: Record<EventType, number> = {
    page_view: 0.1,
    product_view: 0.3,
    search: 0.2,
    add_to_cart: 0.8,
    remove_from_cart: -0.3,
    add_to_wishlist: 0.5,
    purchase: 1.0,
    checkout_start: 0.7,
    checkout_abandon: -0.2
  };
  
  let score = 0;
  events.forEach(e => {
    score += weights[e.type] || 0;
  });
  
  return Math.min(Math.max(score / 10, 0), 1);
}

function calculateCategoryAffinities(events: BehavioralEvent[], products: Product[]): Record<string, number> {
  const affinities: Record<string, number> = {};
  
  events.forEach(e => {
    if (e.productId) {
      const product = products.find(p => p.id === e.productId);
      if (product) {
        affinities[product.category] = (affinities[product.category] || 0) + 1;
      }
    }
  });
  
  // Normalize
  const total = Object.values(affinities).reduce((a, b) => a + b, 0) || 1;
  Object.keys(affinities).forEach(k => {
    affinities[k] = affinities[k] / total;
  });
  
  return affinities;
}

function calculatePurchaseIntent(events: BehavioralEvent[]): number {
  const recentEvents = events.slice(-20);
  let intent = 0.1;
  
  recentEvents.forEach(e => {
    switch (e.type) {
      case 'add_to_cart': intent += 0.15; break;
      case 'checkout_start': intent += 0.3; break;
      case 'product_view': intent += 0.02; break;
      case 'add_to_wishlist': intent += 0.08; break;
    }
  });
  
  return Math.min(intent, 1);
}
