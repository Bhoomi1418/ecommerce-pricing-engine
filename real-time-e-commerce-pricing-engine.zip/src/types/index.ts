// Core Types for E-Commerce Dynamic Pricing Engine

export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  basePrice: number;
  currentPrice: number;
  dynamicPrice: number;
  imageUrl: string;
  description: string;
  inventory: number;
  restockDate?: string;
  demandScore: number;
  competitorPrices: number[];
  margin: number;
  tags: string[];
  rating: number;
  reviewCount: number;
}

export interface UserSession {
  id: string;
  userId: string;
  startTime: number;
  events: BehavioralEvent[];
  engagementScore: number;
  categoryAffinities: Record<string, number>;
  purchaseIntentProbability: number;
  segment: UserSegment;
  device: 'mobile' | 'desktop' | 'tablet';
  referralSource: string;
}

export interface BehavioralEvent {
  id: string;
  timestamp: number;
  type: EventType;
  productId?: string;
  categoryId?: string;
  searchQuery?: string;
  metadata?: Record<string, any>;
}

export type EventType = 
  | 'page_view'
  | 'product_view'
  | 'search'
  | 'add_to_cart'
  | 'remove_from_cart'
  | 'add_to_wishlist'
  | 'purchase'
  | 'checkout_start'
  | 'checkout_abandon';

export interface UserSegment {
  id: string;
  name: string;
  willingnessToPay: 'low' | 'medium' | 'high';
  priceElasticity: number;
  loyaltyScore: number;
}

export interface PricingRule {
  id: string;
  name: string;
  type: 'demand' | 'competition' | 'inventory' | 'segment' | 'time';
  condition: string;
  adjustment: number;
  adjustmentType: 'percentage' | 'absolute';
  priority: number;
  active: boolean;
  minMargin: number;
  maxDiscount: number;
}

export interface PriceExplanation {
  basePrice: number;
  finalPrice: number;
  adjustments: PriceAdjustment[];
  transparencyMessage: string;
}

export interface PriceAdjustment {
  reason: string;
  type: string;
  amount: number;
  icon: string;
}

export interface Recommendation {
  productId: string;
  score: number;
  reason: string;
  algorithm: 'collaborative' | 'session-based' | 'content-based' | 'hybrid';
}

export interface ABTest {
  id: string;
  name: string;
  description: string;
  status: 'running' | 'completed' | 'paused';
  startDate: string;
  endDate?: string;
  variants: ABVariant[];
  metrics: ABMetrics;
  targetMetric: string;
  trafficAllocation: number;
}

export interface ABVariant {
  id: string;
  name: string;
  description: string;
  trafficPercentage: number;
  config: Record<string, any>;
  results: VariantResults;
}

export interface VariantResults {
  visitors: number;
  conversions: number;
  conversionRate: number;
  revenue: number;
  avgOrderValue: number;
  revenuePerSession: number;
  confidence: number;
}

export interface ABMetrics {
  totalVisitors: number;
  totalConversions: number;
  totalRevenue: number;
  statisticalSignificance: number;
  winner?: string;
}

export interface StreamEvent {
  id: string;
  timestamp: number;
  type: EventType;
  userId: string;
  sessionId: string;
  productId?: string;
  data: Record<string, any>;
  processed: boolean;
  latencyMs: number;
}

export interface DemandSignal {
  productId: string;
  viewVelocity: number;
  cartAddRate: number;
  purchaseVelocity: number;
  searchVolume: number;
  timestamp: number;
}

export interface FairnessMetric {
  segment: string;
  avgPriceShown: number;
  avgDiscount: number;
  conversionRate: number;
  variance: number;
  fairnessScore: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  priceAtAdd: number;
}

export interface AnalyticsData {
  revenueUplift: number;
  recommendationHitRate: number;
  ndcg: number;
  p99Latency: number;
  avgLatency: number;
  eventsProcessed: number;
  activeUsers: number;
  conversionRate: number;
  avgOrderValue: number;
}
