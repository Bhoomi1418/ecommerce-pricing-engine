import { Product } from '../types';

export const categories = [
  'Electronics',
  'Fashion',
  'Home & Garden',
  'Sports & Outdoors',
  'Beauty & Health',
  'Books & Media',
  'Toys & Games',
  'Automotive',
  'Grocery',
  'Office Supplies'
];

export const productImages: Record<string, string> = {
  'Electronics': '📱',
  'Fashion': '👕',
  'Home & Garden': '🏠',
  'Sports & Outdoors': '⚽',
  'Beauty & Health': '💄',
  'Books & Media': '📚',
  'Toys & Games': '🎮',
  'Automotive': '🚗',
  'Grocery': '🛒',
  'Office Supplies': '📎'
};

const productNames: Record<string, string[]> = {
  'Electronics': [
    'Wireless Bluetooth Headphones Pro',
    'Ultra HD Smart TV 55"',
    '4K Action Camera',
    'Mechanical Gaming Keyboard',
    'Wireless Charging Pad',
    'Smart Home Hub',
    'Noise Cancelling Earbuds',
    'Portable Power Bank 20000mAh',
    'Smart Watch Series X',
    'Wireless Gaming Mouse'
  ],
  'Fashion': [
    'Premium Cotton T-Shirt',
    'Slim Fit Jeans',
    'Running Sneakers Pro',
    'Winter Down Jacket',
    'Leather Crossbody Bag',
    'Silk Dress Shirt',
    'Athletic Performance Shorts',
    'Wool Blend Cardigan',
    'Classic Aviator Sunglasses',
    'Canvas Backpack'
  ],
  'Home & Garden': [
    'Robot Vacuum Cleaner',
    'Air Purifier HEPA',
    'Smart Thermostat',
    'Memory Foam Mattress',
    'LED Grow Light',
    'Stainless Steel Cookware Set',
    'Smart Doorbell Camera',
    'Cordless Stick Vacuum',
    'Indoor Plant Collection',
    'Smart Light Bulb Pack'
  ],
  'Sports & Outdoors': [
    'Carbon Fiber Tennis Racket',
    'Yoga Mat Premium',
    'Adjustable Dumbbells Set',
    'Camping Tent 4-Person',
    'Mountain Bike Helmet',
    'Resistance Bands Set',
    'Golf Club Set',
    'Swimming Goggles Pro',
    'Hiking Backpack 40L',
    'Fitness Tracker Band'
  ],
  'Beauty & Health': [
    'Anti-Aging Serum',
    'Electric Toothbrush Pro',
    'Hair Dryer Professional',
    'Skincare Set Deluxe',
    'Massage Gun Pro',
    'Vitamin D Supplements',
    'Facial Cleanser Foam',
    'Essential Oil Diffuser',
    'Protein Powder 5lb',
    'Eye Cream Intensive'
  ]
};

function generateProducts(): Product[] {
  const products: Product[] = [];
  let id = 1;

  Object.entries(productNames).forEach(([category, names]) => {
    names.forEach((name, idx) => {
      const basePrice = Math.round((Math.random() * 300 + 20) * 100) / 100;
      const demandScore = Math.random();
      const competitorPrices = Array.from({ length: 3 }, () => 
        Math.round((basePrice * (0.85 + Math.random() * 0.3)) * 100) / 100
      );
      
      const dynamicAdjustment = calculateDynamicPrice(basePrice, demandScore, competitorPrices);
      
      products.push({
        id: `prod_${id.toString().padStart(4, '0')}`,
        name,
        category,
        subcategory: `${category}-Sub${idx % 3 + 1}`,
        basePrice,
        currentPrice: basePrice,
        dynamicPrice: dynamicAdjustment,
        imageUrl: productImages[category] || '📦',
        description: `Premium quality ${name.toLowerCase()} with advanced features and exceptional durability. Perfect for everyday use.`,
        inventory: Math.floor(Math.random() * 500) + 10,
        restockDate: Math.random() > 0.7 ? new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString() : undefined,
        demandScore,
        competitorPrices,
        margin: 0.15 + Math.random() * 0.25,
        tags: generateTags(category, name),
        rating: Math.round((3.5 + Math.random() * 1.5) * 10) / 10,
        reviewCount: Math.floor(Math.random() * 5000) + 50
      });
      id++;
    });
  });

  return products;
}

function calculateDynamicPrice(basePrice: number, demandScore: number, competitorPrices: number[]): number {
  const avgCompetitorPrice = competitorPrices.reduce((a, b) => a + b, 0) / competitorPrices.length;
  const demandMultiplier = 1 + (demandScore - 0.5) * 0.2; // -10% to +10% based on demand
  const competitiveAdjustment = (avgCompetitorPrice - basePrice) * 0.3;
  
  let dynamicPrice = basePrice * demandMultiplier + competitiveAdjustment;
  
  // Apply constraints
  const minPrice = basePrice * 0.85; // Max 15% discount
  const maxPrice = basePrice * 1.15; // Max 15% increase
  
  dynamicPrice = Math.max(minPrice, Math.min(maxPrice, dynamicPrice));
  
  return Math.round(dynamicPrice * 100) / 100;
}

function generateTags(category: string, _name: string): string[] {
  const baseTags = ['trending', 'best-seller', 'new-arrival', 'limited-edition', 'eco-friendly', 'premium'];
  const categoryTags: Record<string, string[]> = {
    'Electronics': ['wireless', 'smart', 'portable', 'rechargeable'],
    'Fashion': ['casual', 'formal', 'athletic', 'vintage'],
    'Home & Garden': ['energy-efficient', 'compact', 'modern', 'durable'],
    'Sports & Outdoors': ['professional', 'beginner-friendly', 'waterproof', 'lightweight'],
    'Beauty & Health': ['organic', 'dermatologist-tested', 'natural', 'clinical-strength']
  };

  const tags = [category.toLowerCase()];
  const catTags = categoryTags[category] || [];
  
  // Add 2-3 random tags
  const allTags = [...baseTags, ...catTags];
  const numTags = 2 + Math.floor(Math.random() * 2);
  
  for (let i = 0; i < numTags; i++) {
    const tag = allTags[Math.floor(Math.random() * allTags.length)];
    if (!tags.includes(tag)) tags.push(tag);
  }

  return tags;
}

export const products = generateProducts();

export const getProductById = (id: string): Product | undefined => 
  products.find(p => p.id === id);

export const getProductsByCategory = (category: string): Product[] =>
  products.filter(p => p.category === category);

export const searchProducts = (query: string): Product[] => {
  const lowerQuery = query.toLowerCase();
  return products.filter(p => 
    p.name.toLowerCase().includes(lowerQuery) ||
    p.category.toLowerCase().includes(lowerQuery) ||
    p.tags.some(t => t.includes(lowerQuery))
  );
};
