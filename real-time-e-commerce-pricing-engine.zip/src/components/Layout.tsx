import { ReactNode } from 'react';
import {
  ShoppingCart,
  BarChart3,
  FlaskConical,
  DollarSign,
  Shield,
  Store,
  Activity,
  Users,
  TrendingUp,
  Clock
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { cn } from '../utils/cn';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { activeView, setActiveView, cart, analytics, session } = useStore();

  const navItems = [
    { id: 'storefront' as const, label: 'Storefront', icon: Store },
    { id: 'dashboard' as const, label: 'Analytics Dashboard', icon: BarChart3 },
    { id: 'ab-testing' as const, label: 'A/B Testing', icon: FlaskConical },
    { id: 'pricing' as const, label: 'Pricing Engine', icon: DollarSign },
    { id: 'fairness' as const, label: 'Fairness & Transparency', icon: Shield },
  ];

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Header */}
      <header className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-2 rounded-lg">
                <Activity className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">PriceFlow</h1>
                <p className="text-xs text-indigo-200">Dynamic Pricing Engine</p>
              </div>
            </div>

            {/* Real-time Stats */}
            <div className="hidden md:flex items-center space-x-6">
              <div className="flex items-center space-x-2 bg-white/10 px-3 py-1.5 rounded-lg">
                <Users className="h-4 w-4 text-indigo-200" />
                <span className="text-sm">
                  <span className="text-indigo-200">Active:</span>{' '}
                  <span className="font-semibold">{analytics.activeUsers.toLocaleString()}</span>
                </span>
              </div>
              <div className="flex items-center space-x-2 bg-white/10 px-3 py-1.5 rounded-lg">
                <Clock className="h-4 w-4 text-indigo-200" />
                <span className="text-sm">
                  <span className="text-indigo-200">p99:</span>{' '}
                  <span className="font-semibold">{analytics.p99Latency}ms</span>
                </span>
              </div>
              <div className="flex items-center space-x-2 bg-white/10 px-3 py-1.5 rounded-lg">
                <TrendingUp className="h-4 w-4 text-green-300" />
                <span className="text-sm">
                  <span className="text-indigo-200">Uplift:</span>{' '}
                  <span className="font-semibold text-green-300">+{analytics.revenueUplift}%</span>
                </span>
              </div>
            </div>

            {/* Session & Cart */}
            <div className="flex items-center space-x-4">
              <div className="hidden lg:block text-right">
                <p className="text-xs text-indigo-200">Session: {session.id.slice(0, 8)}</p>
                <p className="text-xs text-indigo-200">Segment: {session.segment.name}</p>
              </div>
              <button className="relative bg-white/20 p-2 rounded-lg hover:bg-white/30 transition-colors">
                <ShoppingCart className="h-6 w-6" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                    {cartItemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 py-2 overflow-x-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={cn(
                  'flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap',
                  activeView === item.id
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                )}
              >
                <item.icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white font-semibold mb-3">PriceFlow Engine</h3>
              <p className="text-sm">
                Real-time dynamic pricing and personalization powered by behavioral signals and ML.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-3">Key Features</h3>
              <ul className="text-sm space-y-1">
                <li>• Sub-second event processing</li>
                <li>• ML-powered recommendations</li>
                <li>• A/B testing framework</li>
                <li>• Fairness-aware pricing</li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-3">Performance</h3>
              <ul className="text-sm space-y-1">
                <li>• p99 Latency: {analytics.p99Latency}ms</li>
                <li>• Events Processed: {(analytics.eventsProcessed / 1000000).toFixed(2)}M</li>
                <li>• NDCG Score: {analytics.ndcg.toFixed(2)}</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-700 mt-8 pt-6 text-center text-sm">
            <p>© 2024 PriceFlow. Production-Ready E-Commerce Pricing Engine.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
