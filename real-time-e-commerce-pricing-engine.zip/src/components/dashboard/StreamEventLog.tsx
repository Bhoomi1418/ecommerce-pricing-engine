import { useEffect, useState } from 'react';
import { Activity, Clock, User, Package, Search, ShoppingCart, Heart, CreditCard } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';
import { StreamEvent } from '../../types';

const eventIcons: Record<string, typeof Activity> = {
  page_view: Activity,
  product_view: Package,
  search: Search,
  add_to_cart: ShoppingCart,
  remove_from_cart: ShoppingCart,
  add_to_wishlist: Heart,
  purchase: CreditCard,
  checkout_start: CreditCard,
  checkout_abandon: CreditCard,
};

const eventColors: Record<string, string> = {
  page_view: 'text-slate-500 bg-slate-100',
  product_view: 'text-blue-500 bg-blue-100',
  search: 'text-purple-500 bg-purple-100',
  add_to_cart: 'text-green-500 bg-green-100',
  remove_from_cart: 'text-red-500 bg-red-100',
  add_to_wishlist: 'text-pink-500 bg-pink-100',
  purchase: 'text-emerald-500 bg-emerald-100',
  checkout_start: 'text-amber-500 bg-amber-100',
  checkout_abandon: 'text-orange-500 bg-orange-100',
};

export default function StreamEventLog() {
  const { streamEvents } = useStore();
  const [displayedEvents, setDisplayedEvents] = useState<StreamEvent[]>([]);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!isPaused) {
      setDisplayedEvents(streamEvents.slice(0, 10));
    }
  }, [streamEvents, isPaused]);

  const formatTimestamp = (ts: number) => {
    const date = new Date(ts);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-indigo-600" />
          <h3 className="font-semibold text-slate-800">Real-Time Event Stream</h3>
          <span className="flex items-center space-x-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span>Streaming</span>
          </span>
        </div>
        <button
          onClick={() => setIsPaused(!isPaused)}
          className={cn(
            'text-xs px-3 py-1 rounded-full transition-colors',
            isPaused
              ? 'bg-green-100 text-green-700 hover:bg-green-200'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          )}
        >
          {isPaused ? 'Resume' : 'Pause'}
        </button>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {displayedEvents.map((event, index) => {
          const Icon = eventIcons[event.type] || Activity;
          const colorClass = eventColors[event.type] || 'text-slate-500 bg-slate-100';
          
          return (
            <div
              key={event.id}
              className={cn(
                'flex items-center justify-between p-2 rounded-lg border border-slate-100 transition-all',
                index === 0 && !isPaused ? 'animate-pulse bg-indigo-50' : 'bg-slate-50'
              )}
            >
              <div className="flex items-center space-x-3">
                <div className={cn('p-1.5 rounded-lg', colorClass)}>
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-700">
                    {event.type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                  </p>
                  <div className="flex items-center space-x-2 text-xs text-slate-500">
                    <span className="flex items-center">
                      <User className="h-3 w-3 mr-1" />
                      {event.userId.slice(0, 12)}
                    </span>
                    {event.productId && (
                      <span className="flex items-center">
                        <Package className="h-3 w-3 mr-1" />
                        {event.productId}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-1 text-xs text-slate-500">
                  <Clock className="h-3 w-3" />
                  <span>{formatTimestamp(event.timestamp)}</span>
                </div>
                <span
                  className={cn(
                    'text-xs font-medium',
                    event.latencyMs < 50 ? 'text-green-600' : event.latencyMs < 100 ? 'text-amber-600' : 'text-red-500'
                  )}
                >
                  {event.latencyMs}ms
                </span>
              </div>
            </div>
          );
        })}

        {displayedEvents.length === 0 && (
          <div className="text-center py-8 text-slate-400">
            <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No events yet. Interact with the storefront to generate events.</p>
          </div>
        )}
      </div>

      {/* Stream Stats */}
      <div className="mt-4 pt-4 border-t border-slate-200 grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-lg font-bold text-slate-800">{streamEvents.length}</p>
          <p className="text-xs text-slate-500">Total Events</p>
        </div>
        <div>
          <p className="text-lg font-bold text-green-600">
            {streamEvents.length > 0
              ? Math.round(streamEvents.reduce((a, e) => a + e.latencyMs, 0) / streamEvents.length)
              : 0}ms
          </p>
          <p className="text-xs text-slate-500">Avg Latency</p>
        </div>
        <div>
          <p className="text-lg font-bold text-indigo-600">
            {new Set(streamEvents.map(e => e.type)).size}
          </p>
          <p className="text-xs text-slate-500">Event Types</p>
        </div>
      </div>
    </div>
  );
}
