import { useMemo } from 'react';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Activity,
  Zap,
  Target,
  Clock,
  BarChart2
} from 'lucide-react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { useStore } from '../../store/useStore';
import StreamEventLog from './StreamEventLog';

export default function Dashboard() {
  const { analytics, streamEvents, products, demandSignals } = useStore();

  // Generate mock time series data
  const revenueData = useMemo(() => {
    return Array.from({ length: 24 }, (_, i) => ({
      hour: `${i}:00`,
      baseline: Math.round(Math.random() * 5000 + 8000),
      dynamic: Math.round(Math.random() * 5000 + 9500),
    }));
  }, []);

  const latencyData = useMemo(() => {
    return streamEvents.slice(0, 50).map((e, i) => ({
      index: i,
      latency: e.latencyMs,
    })).reverse();
  }, [streamEvents]);

  const categoryDemand = useMemo(() => {
    const categories: Record<string, number> = {};
    products.forEach(p => {
      categories[p.category] = (categories[p.category] || 0) + p.demandScore;
    });
    return Object.entries(categories)
      .map(([name, value]) => ({ name: name.split(' ')[0], value: Math.round(value * 10) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);
  }, [products]);

  const eventTypeDistribution = useMemo(() => {
    const types: Record<string, number> = {};
    streamEvents.forEach(e => {
      types[e.type] = (types[e.type] || 0) + 1;
    });
    return Object.entries(types).map(([name, value]) => ({ name, value }));
  }, [streamEvents]);

  const COLORS = ['#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e'];

  const stats = [
    {
      label: 'Revenue Uplift',
      value: `+${analytics.revenueUplift}%`,
      change: '+2.3%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-green-600',
      bg: 'bg-green-50',
    },
    {
      label: 'Conversion Rate',
      value: `${analytics.conversionRate}%`,
      change: '+0.5%',
      trend: 'up',
      icon: Target,
      color: 'text-indigo-600',
      bg: 'bg-indigo-50',
    },
    {
      label: 'Avg Order Value',
      value: `$${analytics.avgOrderValue}`,
      change: '+$8.50',
      trend: 'up',
      icon: DollarSign,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
    },
    {
      label: 'Active Users',
      value: analytics.activeUsers.toLocaleString(),
      change: '+142',
      trend: 'up',
      icon: Users,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      label: 'Events/sec',
      value: Math.round(analytics.eventsProcessed / 3600).toLocaleString(),
      change: '+12%',
      trend: 'up',
      icon: Activity,
      color: 'text-amber-600',
      bg: 'bg-amber-50',
    },
    {
      label: 'p99 Latency',
      value: `${analytics.p99Latency}ms`,
      change: '-8ms',
      trend: 'down',
      icon: Zap,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Analytics Dashboard</h1>
          <p className="text-slate-500">Real-time performance metrics and insights</p>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <span className="flex items-center space-x-1 text-green-600">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span>Live</span>
          </span>
          <span className="text-slate-400">|</span>
          <span className="text-slate-500">Last updated: just now</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="bg-white rounded-xl shadow-sm border border-slate-200 p-4"
          >
            <div className={`inline-flex p-2 rounded-lg ${stat.bg} mb-3`}>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
            <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
            <p className="text-xs text-slate-500 mt-1">{stat.label}</p>
            <p className={`text-xs mt-1 flex items-center ${stat.trend === 'up' ? 'text-green-600' : 'text-red-500'}`}>
              {stat.trend === 'up' ? (
                <TrendingUp className="h-3 w-3 mr-1" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1" />
              )}
              {stat.change}
            </p>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Comparison */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-slate-800">Revenue: Dynamic vs Baseline</h3>
              <p className="text-sm text-slate-500">24-hour comparison</p>
            </div>
            <div className="flex items-center space-x-4 text-xs">
              <span className="flex items-center space-x-1">
                <span className="w-3 h-3 rounded-full bg-indigo-500"></span>
                <span>Dynamic</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-3 h-3 rounded-full bg-slate-300"></span>
                <span>Baseline</span>
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="hour" tick={{ fontSize: 10 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Area
                type="monotone"
                dataKey="baseline"
                stroke="#cbd5e1"
                fill="#f1f5f9"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="dynamic"
                stroke="#6366f1"
                fill="url(#colorDynamic)"
                strokeWidth={2}
              />
              <defs>
                <linearGradient id="colorDynamic" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Latency Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-slate-800">Event Processing Latency</h3>
              <p className="text-sm text-slate-500">Last 50 events (target: &lt;200ms)</p>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-700">Avg: {analytics.avgLatency}ms</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={latencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="index" tick={{ fontSize: 10 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" domain={[0, 100]} />
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                formatter={(value) => [`${value}ms`, 'Latency']}
              />
              <Line
                type="monotone"
                dataKey="latency"
                stroke="#10b981"
                strokeWidth={2}
                dot={{ fill: '#10b981', strokeWidth: 0, r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Demand */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Category Demand</h3>
            <BarChart2 className="h-4 w-4 text-slate-400" />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={categoryDemand} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 10 }} stroke="#94a3b8" />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 10 }} stroke="#94a3b8" width={70} />
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Bar dataKey="value" fill="#6366f1" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Event Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Event Distribution</h3>
            <Activity className="h-4 w-4 text-slate-400" />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={eventTypeDistribution}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={70}
                paddingAngle={2}
                dataKey="value"
              >
                {eventTypeDistribution.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap justify-center gap-2 mt-2">
            {eventTypeDistribution.slice(0, 4).map((item, i) => (
              <span key={item.name} className="flex items-center space-x-1 text-xs">
                <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }}></span>
                <span className="text-slate-600">{item.name}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Demand Signals */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Real-Time Demand Signals</h3>
            <Zap className="h-4 w-4 text-amber-500" />
          </div>
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {demandSignals.slice(0, 6).map((signal) => {
              const product = products.find(p => p.id === signal.productId);
              return (
                <div key={signal.productId} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 min-w-0">
                    <span className="text-lg">{product?.imageUrl}</span>
                    <span className="text-sm text-slate-700 truncate">{product?.name.slice(0, 20)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full"
                        style={{ width: `${Math.min(signal.viewVelocity * 100, 100)}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-500 w-8">
                      {(signal.viewVelocity * 10).toFixed(1)}
                    </span>
                  </div>
                </div>
              );
            })}
            {demandSignals.length === 0 && (
              <p className="text-sm text-slate-400 text-center py-4">
                No demand signals yet. Browse products to generate signals.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Stream Event Log */}
      <StreamEventLog />

      {/* Model Performance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
          <h3 className="font-semibold mb-2">Recommendation Model</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-indigo-200">Hit Rate</span>
                <span className="font-bold">{(analytics.recommendationHitRate * 100).toFixed(1)}%</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div
                  className="h-full bg-white rounded-full"
                  style={{ width: `${analytics.recommendationHitRate * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-indigo-200">NDCG Score</span>
                <span className="font-bold">{analytics.ndcg.toFixed(2)}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div
                  className="h-full bg-white rounded-full"
                  style={{ width: `${analytics.ndcg * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl p-6 text-white">
          <h3 className="font-semibold mb-2">Pricing Model</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-emerald-200">Revenue Uplift</span>
                <span className="font-bold">+{analytics.revenueUplift}%</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div
                  className="h-full bg-white rounded-full"
                  style={{ width: `${Math.min(analytics.revenueUplift * 5, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-emerald-200">Margin Protection</span>
                <span className="font-bold">98.5%</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div className="h-full bg-white rounded-full" style={{ width: '98.5%' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl p-6 text-white">
          <h3 className="font-semibold mb-2">System Performance</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-amber-200">p99 Latency Target</span>
                <span className="font-bold">{analytics.p99Latency}ms / 200ms</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div
                  className="h-full bg-white rounded-full"
                  style={{ width: `${(1 - analytics.p99Latency / 200) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-amber-200">Events Processed</span>
                <span className="font-bold">{(analytics.eventsProcessed / 1000000).toFixed(2)}M</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div className="h-full bg-white rounded-full" style={{ width: '85%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
