import { useState } from 'react';
import {
  Shield,
  AlertTriangle,
  CheckCircle,
  Users,
  Info,
  Eye,
  Scale,
  FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

export default function FairnessTransparency() {
  const { fairnessMetrics, products, session } = useStore();
  const [selectedSegment, setSelectedSegment] = useState<string | null>(null);

  // Calculate overall fairness score
  const overallFairnessScore = fairnessMetrics.reduce(
    (sum, m) => sum + m.fairnessScore,
    0
  ) / fairnessMetrics.length;

  // Radar chart data for fairness dimensions
  const radarData = [
    { dimension: 'Price Parity', value: 95, fullMark: 100 },
    { dimension: 'Segment Equity', value: 92, fullMark: 100 },
    { dimension: 'Transparency', value: 98, fullMark: 100 },
    { dimension: 'Consistency', value: 94, fullMark: 100 },
    { dimension: 'Non-Discrimination', value: 97, fullMark: 100 },
    { dimension: 'Explainability', value: 96, fullMark: 100 },
  ];

  // Example product with price explanation
  const exampleProduct = products[0];
  const priceExplanation = {
    basePrice: exampleProduct?.basePrice || 100,
    factors: [
      { name: 'Base Price', value: exampleProduct?.basePrice || 100, type: 'base' },
      { name: 'Current Demand', value: (exampleProduct?.demandScore || 0.5) > 0.7 ? 5 : -2, type: 'adjustment', description: 'Based on real-time shopping activity' },
      { name: 'Limited Stock', value: (exampleProduct?.inventory || 100) < 50 ? 3 : 0, type: 'adjustment', description: 'Low inventory drives slight premium' },
      { name: 'Competitive Pricing', value: -4, type: 'adjustment', description: 'Matched to market average' },
    ],
    finalPrice: exampleProduct?.dynamicPrice || 99,
  };

  // Audit log entries
  const auditLog = [
    { timestamp: '2024-01-15 14:32:05', event: 'Pricing Rule Updated', details: 'Max discount cap changed from 15% to 20%', user: 'system' },
    { timestamp: '2024-01-15 12:15:22', event: 'Fairness Audit Passed', details: 'All segments within 5% variance threshold', user: 'auto-audit' },
    { timestamp: '2024-01-14 09:45:11', event: 'Segment WTP Recalibrated', details: 'ML model retrained with latest behavioral data', user: 'ml-pipeline' },
    { timestamp: '2024-01-13 16:20:33', event: 'Price Override Blocked', details: 'Attempted 25% premium on Budget segment rejected', user: 'rule-engine' },
    { timestamp: '2024-01-13 11:05:48', event: 'Transparency Report Generated', details: 'Q1 pricing transparency report available', user: 'compliance' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Fairness & Transparency</h1>
          <p className="text-slate-500">Ensuring ethical pricing and clear price explanations</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className={cn(
            'flex items-center space-x-2 px-4 py-2 rounded-lg',
            overallFairnessScore >= 0.95 ? 'bg-green-100 text-green-700' :
            overallFairnessScore >= 0.90 ? 'bg-amber-100 text-amber-700' :
            'bg-red-100 text-red-700'
          )}>
            {overallFairnessScore >= 0.95 ? (
              <CheckCircle className="h-5 w-5" />
            ) : (
              <AlertTriangle className="h-5 w-5" />
            )}
            <span className="font-medium">Fairness Score: {(overallFairnessScore * 100).toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Shield className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">{(overallFairnessScore * 100).toFixed(0)}%</p>
              <p className="text-xs text-slate-500">Overall Fairness</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{fairnessMetrics.length}</p>
              <p className="text-xs text-slate-500">Segments Monitored</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Scale className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">3.2%</p>
              <p className="text-xs text-slate-500">Max Price Variance</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-100 rounded-lg">
              <Eye className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">100%</p>
              <p className="text-xs text-slate-500">Price Explainability</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Segment Fairness Table */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">Segment Fairness Analysis</h2>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full flex items-center">
              <CheckCircle className="h-3 w-3 mr-1" />
              All Within Threshold
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs text-slate-500 border-b border-slate-200">
                  <th className="pb-3 font-medium">Segment</th>
                  <th className="pb-3 font-medium">Avg Price</th>
                  <th className="pb-3 font-medium">Avg Discount</th>
                  <th className="pb-3 font-medium">Conv. Rate</th>
                  <th className="pb-3 font-medium">Variance</th>
                  <th className="pb-3 font-medium">Fairness</th>
                </tr>
              </thead>
              <tbody>
                {fairnessMetrics.map((metric) => (
                  <tr
                    key={metric.segment}
                    onClick={() => setSelectedSegment(
                      selectedSegment === metric.segment ? null : metric.segment
                    )}
                    className={cn(
                      'border-b border-slate-100 cursor-pointer transition-colors',
                      selectedSegment === metric.segment ? 'bg-indigo-50' : 'hover:bg-slate-50'
                    )}
                  >
                    <td className="py-3">
                      <span className="font-medium text-slate-800">{metric.segment}</span>
                    </td>
                    <td className="py-3 text-slate-700">${metric.avgPriceShown.toFixed(2)}</td>
                    <td className="py-3 text-green-600">{metric.avgDiscount.toFixed(1)}%</td>
                    <td className="py-3 text-slate-700">{metric.conversionRate.toFixed(1)}%</td>
                    <td className="py-3">
                      <span className={cn(
                        'text-xs font-medium',
                        metric.variance < 0.05 ? 'text-green-600' : 
                        metric.variance < 0.08 ? 'text-amber-600' : 'text-red-500'
                      )}>
                        {(metric.variance * 100).toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className={cn(
                              'h-full rounded-full',
                              metric.fairnessScore >= 0.95 ? 'bg-green-500' :
                              metric.fairnessScore >= 0.90 ? 'bg-amber-500' : 'bg-red-500'
                            )}
                            style={{ width: `${metric.fairnessScore * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-600">
                          {(metric.fairnessScore * 100).toFixed(0)}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Fairness Radar */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Fairness Dimensions</h2>
          <ResponsiveContainer width="100%" height={250}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="dimension" tick={{ fontSize: 10, fill: '#64748b' }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
              <Radar
                name="Score"
                dataKey="value"
                stroke="#6366f1"
                fill="#6366f1"
                fillOpacity={0.3}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Price Transparency Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Price Explanation Demo */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Info className="h-5 w-5 text-indigo-600" />
            <h2 className="font-semibold text-slate-800">Price Transparency Example</h2>
          </div>

          <div className="bg-white rounded-lg p-4 mb-4">
            <div className="flex items-center space-x-3 mb-4">
              <span className="text-4xl">{exampleProduct?.imageUrl || '📦'}</span>
              <div>
                <p className="font-medium text-slate-800">{exampleProduct?.name || 'Sample Product'}</p>
                <p className="text-sm text-slate-500">{exampleProduct?.category || 'Category'}</p>
              </div>
            </div>

            <div className="space-y-2">
              {priceExplanation.factors.map((factor, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {factor.type === 'base' ? (
                      <span className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-xs">💰</span>
                    ) : factor.value > 0 ? (
                      <span className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center text-xs">↑</span>
                    ) : factor.value < 0 ? (
                      <span className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center text-xs">↓</span>
                    ) : (
                      <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs">-</span>
                    )}
                    <div>
                      <span className="text-sm text-slate-700">{factor.name}</span>
                      {factor.description && (
                        <p className="text-xs text-slate-500">{factor.description}</p>
                      )}
                    </div>
                  </div>
                  <span className={cn(
                    'text-sm font-medium',
                    factor.type === 'base' ? 'text-slate-800' :
                    factor.value > 0 ? 'text-red-600' :
                    factor.value < 0 ? 'text-green-600' : 'text-slate-400'
                  )}>
                    {factor.type === 'base' ? `$${factor.value.toFixed(2)}` :
                     factor.value > 0 ? `+$${factor.value.toFixed(2)}` :
                     `$${factor.value.toFixed(2)}`}
                  </span>
                </div>
              ))}
              <div className="border-t border-slate-200 pt-2 mt-2 flex items-center justify-between">
                <span className="font-semibold text-slate-800">Final Price</span>
                <span className="text-xl font-bold text-indigo-600">
                  ${priceExplanation.finalPrice.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-600 flex items-start space-x-2">
            <Info className="h-4 w-4 text-indigo-500 flex-shrink-0 mt-0.5" />
            <span>
              This breakdown shows how prices are calculated transparently. 
              All adjustments are based on market conditions, not personal demographics.
            </span>
          </p>
        </div>

        {/* Your Session Info */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Users className="h-5 w-5 text-slate-600" />
            <h2 className="font-semibold text-slate-800">Your Pricing Profile</h2>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-500 mb-1">Your Segment</p>
              <p className="font-semibold text-slate-800">{session.segment.name}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-slate-50 rounded-lg">
                <p className="text-xs text-slate-500 mb-1">Price Sensitivity</p>
                <p className="font-medium text-slate-800">
                  {session.segment.priceElasticity > 1.5 ? 'High' :
                   session.segment.priceElasticity > 0.8 ? 'Medium' : 'Low'}
                </p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <p className="text-xs text-slate-500 mb-1">Loyalty Score</p>
                <p className="font-medium text-slate-800">
                  {(session.segment.loyaltyScore * 100).toFixed(0)}%
                </p>
              </div>
            </div>

            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <Shield className="h-5 w-5 text-green-600 flex-shrink-0" />
                <div>
                  <p className="font-medium text-green-800">Fair Pricing Guarantee</p>
                  <p className="text-sm text-green-700 mt-1">
                    Your prices are determined solely by market factors (demand, inventory, competition) 
                    and never by personal demographics such as location, age, or browsing history.
                  </p>
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-500 flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>View our <a href="#" className="text-indigo-600 underline">Pricing Policy</a> for more details</span>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Log */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-slate-600" />
            <h2 className="font-semibold text-slate-800">Fairness Audit Log</h2>
          </div>
          <button className="text-sm text-indigo-600 hover:text-indigo-700">Export Report</button>
        </div>

        <div className="space-y-3">
          {auditLog.map((entry, i) => (
            <div key={i} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
              <div className={cn(
                'p-1.5 rounded-lg',
                entry.event.includes('Passed') || entry.event.includes('Generated') ? 'bg-green-100' :
                entry.event.includes('Blocked') ? 'bg-red-100' :
                entry.event.includes('Updated') || entry.event.includes('Recalibrated') ? 'bg-blue-100' :
                'bg-slate-200'
              )}>
                {entry.event.includes('Passed') ? <CheckCircle className="h-4 w-4 text-green-600" /> :
                 entry.event.includes('Blocked') ? <AlertTriangle className="h-4 w-4 text-red-500" /> :
                 <Info className="h-4 w-4 text-blue-600" />}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-slate-800 text-sm">{entry.event}</p>
                  <span className="text-xs text-slate-400">{entry.timestamp}</span>
                </div>
                <p className="text-sm text-slate-600">{entry.details}</p>
                <p className="text-xs text-slate-400 mt-1">By: {entry.user}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Non-Discrimination Policy */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 text-white">
        <div className="flex items-start space-x-4">
          <div className="p-3 bg-white/10 rounded-lg">
            <Scale className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold mb-2">Non-Discrimination Commitment</h2>
            <p className="text-slate-300 mb-4">
              Our dynamic pricing engine is designed with fairness as a core principle. We commit to:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3 bg-white/10 rounded-lg">
                <h3 className="font-medium mb-1">No Demographic Pricing</h3>
                <p className="text-sm text-slate-400">
                  Prices never vary based on user demographics, location discrimination, or personal attributes
                </p>
              </div>
              <div className="p-3 bg-white/10 rounded-lg">
                <h3 className="font-medium mb-1">Transparent Factors</h3>
                <p className="text-sm text-slate-400">
                  All price changes are explainable and based on legitimate market factors
                </p>
              </div>
              <div className="p-3 bg-white/10 rounded-lg">
                <h3 className="font-medium mb-1">Regular Audits</h3>
                <p className="text-sm text-slate-400">
                  Automated fairness checks run continuously with human oversight and reporting
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
