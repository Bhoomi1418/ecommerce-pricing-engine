import { Brain, Target, Activity, TrendingUp } from 'lucide-react';
import { useStore } from '../../store/useStore';

export default function SessionInsights() {
  const { session } = useStore();

  const topCategories = Object.entries(session.categoryAffinities)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
      <div className="flex items-center space-x-2 mb-4">
        <Brain className="h-5 w-5 text-indigo-600" />
        <h3 className="font-semibold text-slate-800">Session Insights</h3>
      </div>

      <div className="space-y-4">
        {/* Engagement Score */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-500 flex items-center">
              <Activity className="h-3 w-3 mr-1" />
              Engagement Score
            </span>
            <span className="text-xs font-medium text-slate-700">
              {(session.engagementScore * 100).toFixed(0)}%
            </span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${session.engagementScore * 100}%` }}
            />
          </div>
        </div>

        {/* Purchase Intent */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-500 flex items-center">
              <Target className="h-3 w-3 mr-1" />
              Purchase Intent
            </span>
            <span className="text-xs font-medium text-slate-700">
              {(session.purchaseIntentProbability * 100).toFixed(0)}%
            </span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${session.purchaseIntentProbability * 100}%` }}
            />
          </div>
        </div>

        {/* Category Affinities */}
        {topCategories.length > 0 && (
          <div>
            <p className="text-xs text-slate-500 mb-2 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              Top Interests
            </p>
            <div className="space-y-1">
              {topCategories.map(([category, score]) => (
                <div key={category} className="flex items-center justify-between">
                  <span className="text-xs text-slate-700">{category}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-400 rounded-full"
                        style={{ width: `${score * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-500 w-8">
                      {(score * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Session Info */}
        <div className="pt-3 border-t border-slate-100">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 rounded-lg p-2">
              <p className="text-slate-500">Device</p>
              <p className="font-medium text-slate-700 capitalize">{session.device}</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-2">
              <p className="text-slate-500">Source</p>
              <p className="font-medium text-slate-700 capitalize">{session.referralSource}</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-2 col-span-2">
              <p className="text-slate-500">Segment</p>
              <p className="font-medium text-slate-700">{session.segment.name}</p>
            </div>
          </div>
        </div>

        {/* Events Count */}
        <div className="text-center py-2 bg-indigo-50 rounded-lg">
          <p className="text-xs text-indigo-600">
            <span className="font-bold">{session.events.length}</span> events tracked this session
          </p>
        </div>
      </div>
    </div>
  );
}
