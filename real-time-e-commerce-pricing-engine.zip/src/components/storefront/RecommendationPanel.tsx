import { useMemo } from 'react';
import { Sparkles, ShoppingCart, Brain, Users, Clock } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { Recommendation } from '../../types';

export default function RecommendationPanel() {
  const { products, session, addToCart } = useStore();

  // Generate recommendations based on session data
  const recommendations = useMemo((): (Recommendation & { product: typeof products[0] })[] => {
    const recs: (Recommendation & { product: typeof products[0] })[] = [];
    
    // Get viewed product categories
    const viewedCategories = Object.keys(session.categoryAffinities);
    
    // Session-based recommendations (most relevant)
    if (viewedCategories.length > 0) {
      const topCategory = Object.entries(session.categoryAffinities)
        .sort(([, a], [, b]) => b - a)[0]?.[0];
      
      if (topCategory) {
        const categoryProducts = products
          .filter(p => p.category === topCategory)
          .sort((a, b) => b.rating - a.rating)
          .slice(0, 2);
        
        categoryProducts.forEach(product => {
          recs.push({
            productId: product.id,
            product,
            score: 0.95,
            reason: 'Based on your browsing',
            algorithm: 'session-based'
          });
        });
      }
    }

    // Collaborative filtering recommendations
    const popularProducts = products
      .sort((a, b) => b.demandScore - a.demandScore)
      .filter(p => !recs.some(r => r.productId === p.id))
      .slice(0, 2);

    popularProducts.forEach(product => {
      recs.push({
        productId: product.id,
        product,
        score: 0.85,
        reason: 'Popular with similar users',
        algorithm: 'collaborative'
      });
    });

    // Cold-start handling - use contextual signals
    if (session.events.length < 3) {
      const contextProducts = products
        .filter(p => {
          // Use device and time context for cold start
          if (session.device === 'mobile' && p.tags.includes('portable')) return true;
          if (session.referralSource === 'social' && p.tags.includes('trending')) return true;
          return p.demandScore > 0.7;
        })
        .filter(p => !recs.some(r => r.productId === p.id))
        .slice(0, 2);

      contextProducts.forEach(product => {
        recs.push({
          productId: product.id,
          product,
          score: 0.75,
          reason: 'Recommended for you',
          algorithm: 'content-based'
        });
      });
    }

    return recs.slice(0, 4);
  }, [products, session]);

  const getAlgorithmIcon = (algorithm: string) => {
    switch (algorithm) {
      case 'session-based': return <Clock className="h-3 w-3" />;
      case 'collaborative': return <Users className="h-3 w-3" />;
      case 'content-based': return <Brain className="h-3 w-3" />;
      default: return <Sparkles className="h-3 w-3" />;
    }
  };

  const getAlgorithmLabel = (algorithm: string) => {
    switch (algorithm) {
      case 'session-based': return 'Session AI';
      case 'collaborative': return 'Collaborative';
      case 'content-based': return 'Contextual';
      default: return 'Hybrid';
    }
  };

  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-200 p-4">
      <div className="flex items-center space-x-2 mb-4">
        <Sparkles className="h-5 w-5 text-purple-600" />
        <h3 className="font-semibold text-slate-800">For You</h3>
        <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
          AI Powered
        </span>
      </div>

      <div className="space-y-3">
        {recommendations.map((rec) => (
          <div
            key={rec.productId}
            className="bg-white rounded-lg p-3 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start space-x-3">
              <span className="text-3xl">{rec.product.imageUrl}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-800 line-clamp-1">
                  {rec.product.name}
                </p>
                <p className="text-xs text-slate-500 mb-1">{rec.reason}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-indigo-600">
                    ${rec.product.dynamicPrice.toFixed(2)}
                  </span>
                  <div className="flex items-center space-x-1 text-xs text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">
                    {getAlgorithmIcon(rec.algorithm)}
                    <span>{getAlgorithmLabel(rec.algorithm)}</span>
                  </div>
                </div>
              </div>
            </div>
            <button
              onClick={() => addToCart(rec.product)}
              className="w-full mt-2 py-1.5 text-xs font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors flex items-center justify-center space-x-1"
            >
              <ShoppingCart className="h-3 w-3" />
              <span>Add to Cart</span>
            </button>
          </div>
        ))}

        {recommendations.length === 0 && (
          <div className="text-center py-4">
            <p className="text-sm text-slate-500">
              Browse products to get personalized recommendations
            </p>
          </div>
        )}
      </div>

      {/* Model Info */}
      <div className="mt-4 pt-3 border-t border-purple-200">
        <p className="text-xs text-slate-500">
          Recommendations powered by hybrid model combining GRU4Rec session sequences 
          with collaborative filtering and contextual signals.
        </p>
        <div className="flex items-center space-x-4 mt-2 text-xs text-purple-600">
          <span>Hit Rate: 34.2%</span>
          <span>NDCG: 0.78</span>
        </div>
      </div>
    </div>
  );
}
