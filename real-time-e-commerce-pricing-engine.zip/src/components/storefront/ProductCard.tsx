import { useState } from 'react';
import {
  ShoppingCart,
  Heart,
  TrendingUp,
  TrendingDown,
  Info,
  Star,
  Package,
  Zap
} from 'lucide-react';
import { Product, PriceExplanation } from '../../types';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [showPriceExplanation, setShowPriceExplanation] = useState(false);
  const { addToCart, trackEvent } = useStore();

  const priceDiff = product.dynamicPrice - product.basePrice;
  const priceChangePercent = ((priceDiff / product.basePrice) * 100).toFixed(1);
  const isDiscount = priceDiff < 0;

  const handleProductView = () => {
    trackEvent('product_view', product.id);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackEvent('add_to_wishlist', product.id);
  };

  const getPriceExplanation = (): PriceExplanation => {
    const adjustments = [];
    
    if (product.demandScore > 0.7) {
      adjustments.push({
        reason: 'High Demand',
        type: 'demand',
        amount: product.basePrice * 0.05,
        icon: '🔥'
      });
    }
    
    if (product.inventory < 50) {
      adjustments.push({
        reason: 'Limited Stock',
        type: 'inventory',
        amount: product.basePrice * 0.03,
        icon: '📦'
      });
    }
    
    const avgCompetitorPrice = product.competitorPrices.reduce((a, b) => a + b, 0) / product.competitorPrices.length;
    if (avgCompetitorPrice < product.basePrice) {
      adjustments.push({
        reason: 'Competitive Pricing',
        type: 'competition',
        amount: -(product.basePrice * 0.08),
        icon: '🏷️'
      });
    }

    return {
      basePrice: product.basePrice,
      finalPrice: product.dynamicPrice,
      adjustments,
      transparencyMessage: isDiscount 
        ? "You're getting a great deal! Price adjusted based on current market conditions."
        : "Price reflects current demand and availability."
    };
  };

  const explanation = getPriceExplanation();

  return (
    <div 
      className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-300 group"
      onClick={handleProductView}
    >
      {/* Product Image */}
      <div className="relative aspect-square bg-gradient-to-br from-slate-100 to-slate-50 flex items-center justify-center">
        <span className="text-6xl group-hover:scale-110 transition-transform duration-300">
          {product.imageUrl}
        </span>
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col space-y-2">
          {product.demandScore > 0.8 && (
            <span className="bg-red-500 text-white text-xs font-semibold px-2 py-1 rounded-full flex items-center">
              <Zap className="h-3 w-3 mr-1" />
              Hot
            </span>
          )}
          {isDiscount && (
            <span className="bg-green-500 text-white text-xs font-semibold px-2 py-1 rounded-full">
              {priceChangePercent}%
            </span>
          )}
          {product.inventory < 30 && (
            <span className="bg-amber-500 text-white text-xs font-semibold px-2 py-1 rounded-full flex items-center">
              <Package className="h-3 w-3 mr-1" />
              Low Stock
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleWishlist}
          className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-sm hover:bg-white hover:text-red-500 transition-colors"
        >
          <Heart className="h-5 w-5" />
        </button>
      </div>

      {/* Product Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
            {product.category}
          </span>
          <div className="flex items-center space-x-1 text-amber-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="text-xs font-medium text-slate-700">{product.rating}</span>
            <span className="text-xs text-slate-400">({product.reviewCount})</span>
          </div>
        </div>

        <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>

        {/* Pricing */}
        <div className="mb-3">
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-slate-900">
              ${product.dynamicPrice.toFixed(2)}
            </span>
            {product.dynamicPrice !== product.basePrice && (
              <span className="text-sm text-slate-400 line-through">
                ${product.basePrice.toFixed(2)}
              </span>
            )}
          </div>
          
          {/* Price Trend Indicator */}
          <div className="flex items-center mt-1 space-x-2">
            {priceDiff !== 0 && (
              <span className={cn(
                'flex items-center text-xs font-medium',
                isDiscount ? 'text-green-600' : 'text-red-500'
              )}>
                {isDiscount ? (
                  <TrendingDown className="h-3 w-3 mr-1" />
                ) : (
                  <TrendingUp className="h-3 w-3 mr-1" />
                )}
                {isDiscount ? 'Down' : 'Up'} {Math.abs(parseFloat(priceChangePercent))}%
              </span>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowPriceExplanation(!showPriceExplanation);
              }}
              className="text-slate-400 hover:text-indigo-600 transition-colors"
            >
              <Info className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Price Explanation Panel */}
        {showPriceExplanation && (
          <div className="bg-slate-50 rounded-lg p-3 mb-3 text-xs border border-slate-200">
            <p className="font-medium text-slate-700 mb-2">Price Breakdown</p>
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Base Price</span>
                <span>${explanation.basePrice.toFixed(2)}</span>
              </div>
              {explanation.adjustments.map((adj, i) => (
                <div key={i} className="flex justify-between">
                  <span className="text-slate-500">
                    {adj.icon} {adj.reason}
                  </span>
                  <span className={adj.amount < 0 ? 'text-green-600' : 'text-red-500'}>
                    {adj.amount < 0 ? '-' : '+'}${Math.abs(adj.amount).toFixed(2)}
                  </span>
                </div>
              ))}
              <div className="border-t border-slate-200 pt-1 mt-1 flex justify-between font-medium">
                <span>Final Price</span>
                <span>${explanation.finalPrice.toFixed(2)}</span>
              </div>
            </div>
            <p className="text-slate-500 mt-2 text-[10px] italic">
              {explanation.transparencyMessage}
            </p>
          </div>
        )}

        {/* Add to Cart */}
        <button
          onClick={handleAddToCart}
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2.5 rounded-lg font-medium flex items-center justify-center space-x-2 hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm hover:shadow-md"
        >
          <ShoppingCart className="h-4 w-4" />
          <span>Add to Cart</span>
        </button>
      </div>
    </div>
  );
}
