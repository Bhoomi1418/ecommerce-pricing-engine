import { useMemo, useState, useEffect } from 'react';
import { Search, Filter, X, Sparkles, Clock, Flame, TrendingUp } from 'lucide-react';
import { useStore } from '../../store/useStore';
import ProductCard from './ProductCard';
import RecommendationPanel from './RecommendationPanel';
import CartPanel from './CartPanel';
import SessionInsights from './SessionInsights';
import { categories } from '../../data/products';
import { cn } from '../../utils/cn';

export default function Storefront() {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    trackEvent
  } = useStore();

  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'relevance' | 'price-low' | 'price-high' | 'demand'>('relevance');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);

  // Track page view on mount
  useEffect(() => {
    trackEvent('page_view');
  }, [trackEvent]);

  // Track search queries
  useEffect(() => {
    if (searchQuery) {
      trackEvent('search', undefined, { query: searchQuery });
    }
  }, [searchQuery, trackEvent]);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Category filter
    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.tags.some(t => t.includes(query))
      );
    }

    // Price range filter
    result = result.filter(p => 
      p.dynamicPrice >= priceRange[0] && p.dynamicPrice <= priceRange[1]
    );

    // Sort
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.dynamicPrice - b.dynamicPrice);
        break;
      case 'price-high':
        result.sort((a, b) => b.dynamicPrice - a.dynamicPrice);
        break;
      case 'demand':
        result.sort((a, b) => b.demandScore - a.demandScore);
        break;
      default:
        // Relevance - mix of demand and rating
        result.sort((a, b) => (b.demandScore * 0.5 + b.rating / 5 * 0.5) - (a.demandScore * 0.5 + a.rating / 5 * 0.5));
    }

    return result;
  }, [products, selectedCategory, searchQuery, sortBy, priceRange]);

  const trendingProducts = useMemo(() => {
    return [...products]
      .sort((a, b) => b.demandScore - a.demandScore)
      .slice(0, 4);
  }, [products]);

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 rounded-2xl p-8 text-white shadow-xl">
        <div className="max-w-2xl">
          <div className="flex items-center space-x-2 mb-4">
            <Sparkles className="h-5 w-5" />
            <span className="text-sm font-medium bg-white/20 px-3 py-1 rounded-full">
              AI-Powered Pricing
            </span>
          </div>
          <h1 className="text-3xl font-bold mb-3">
            Dynamic Prices, Personalized for You
          </h1>
          <p className="text-indigo-100 mb-6">
            Our real-time pricing engine analyzes demand, competition, and your preferences 
            to deliver the best possible prices. Prices update every second!
          </p>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, categories, brands..."
              className="w-full pl-12 pr-4 py-3 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Categories */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-slate-800">Categories</h2>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-1 text-sm text-indigo-600 hover:text-indigo-700"
              >
                <Filter className="h-4 w-4" />
                <span>Filters</span>
              </button>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  !selectedCategory
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                )}
              >
                All Products
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={cn(
                    'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Expanded Filters */}
            {showFilters && (
              <div className="mt-4 pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Sort By
                  </label>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="relevance">Relevance</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="demand">Trending</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Price Range: ${priceRange[0]} - ${priceRange[1]}
                  </label>
                  <div className="flex space-x-4">
                    <input
                      type="range"
                      min="0"
                      max="500"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                      className="flex-1"
                    />
                    <input
                      type="range"
                      min="0"
                      max="500"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                      className="flex-1"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Trending Section */}
          <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200 p-4">
            <div className="flex items-center space-x-2 mb-4">
              <Flame className="h-5 w-5 text-orange-500" />
              <h2 className="font-semibold text-slate-800">Trending Now</h2>
              <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">
                High Demand
              </span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {trendingProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-lg p-3 flex items-center space-x-3 hover:shadow-md transition-shadow cursor-pointer"
                >
                  <span className="text-3xl">{product.imageUrl}</span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">{product.name}</p>
                    <div className="flex items-center space-x-1">
                      <span className="text-sm font-bold text-indigo-600">${product.dynamicPrice.toFixed(2)}</span>
                      <TrendingUp className="h-3 w-3 text-green-500" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Product Grid */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-slate-600">
                Showing <span className="font-medium">{filteredProducts.length}</span> products
              </p>
              <div className="flex items-center space-x-2 text-xs text-slate-500">
                <Clock className="h-4 w-4" />
                <span>Prices update in real-time</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12 bg-white rounded-xl border border-slate-200">
                <p className="text-slate-500">No products found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <SessionInsights />
          <CartPanel />
          <RecommendationPanel />
        </div>
      </div>
    </div>
  );
}
