import { ShoppingCart, Plus, Minus, Trash2, CreditCard } from 'lucide-react';
import { useStore } from '../../store/useStore';

export default function CartPanel() {
  const { cart, updateCartQuantity, removeFromCart, clearCart, trackEvent } = useStore();

  const subtotal = cart.reduce(
    (sum, item) => sum + item.product.dynamicPrice * item.quantity,
    0
  );

  const savings = cart.reduce(
    (sum, item) => sum + (item.product.basePrice - item.product.dynamicPrice) * item.quantity,
    0
  );

  const handleCheckout = () => {
    trackEvent('checkout_start');
    // Simulate checkout
    cart.forEach(item => {
      trackEvent('purchase', item.product.id, { quantity: item.quantity, price: item.product.dynamicPrice });
    });
    clearCart();
    alert('Order placed successfully! Thank you for your purchase.');
  };

  if (cart.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
        <div className="flex items-center space-x-2 mb-4">
          <ShoppingCart className="h-5 w-5 text-slate-400" />
          <h3 className="font-semibold text-slate-800">Your Cart</h3>
        </div>
        <div className="text-center py-8">
          <ShoppingCart className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Your cart is empty</p>
          <p className="text-slate-400 text-xs mt-1">Add items to get started</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <ShoppingCart className="h-5 w-5 text-indigo-600" />
          <h3 className="font-semibold text-slate-800">Your Cart</h3>
          <span className="bg-indigo-100 text-indigo-700 text-xs font-medium px-2 py-0.5 rounded-full">
            {cart.reduce((sum, item) => sum + item.quantity, 0)}
          </span>
        </div>
        <button
          onClick={clearCart}
          className="text-xs text-slate-400 hover:text-red-500 transition-colors"
        >
          Clear
        </button>
      </div>

      <div className="space-y-3 max-h-64 overflow-y-auto">
        {cart.map((item) => (
          <div key={item.product.id} className="flex items-center space-x-3 bg-slate-50 rounded-lg p-2">
            <span className="text-2xl">{item.product.imageUrl}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800 truncate">
                {item.product.name}
              </p>
              <p className="text-sm font-bold text-indigo-600">
                ${item.product.dynamicPrice.toFixed(2)}
              </p>
            </div>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100"
              >
                <Minus className="h-3 w-3" />
              </button>
              <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
              <button
                onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100"
              >
                <Plus className="h-3 w-3" />
              </button>
              <button
                onClick={() => removeFromCart(item.product.id)}
                className="p-1 rounded text-slate-400 hover:text-red-500 hover:bg-red-50"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-200 space-y-2">
        {savings > 0 && (
          <div className="flex justify-between text-sm">
            <span className="text-green-600">You're saving</span>
            <span className="font-medium text-green-600">-${savings.toFixed(2)}</span>
          </div>
        )}
        <div className="flex justify-between">
          <span className="text-slate-600">Subtotal</span>
          <span className="font-bold text-slate-800">${subtotal.toFixed(2)}</span>
        </div>
      </div>

      <button
        onClick={handleCheckout}
        className="w-full mt-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-lg font-medium flex items-center justify-center space-x-2 hover:from-green-700 hover:to-emerald-700 transition-all shadow-sm"
      >
        <CreditCard className="h-4 w-4" />
        <span>Checkout</span>
      </button>
    </div>
  );
}
