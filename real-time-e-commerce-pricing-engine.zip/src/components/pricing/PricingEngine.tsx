import { useState, useMemo } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Settings,
  CheckCircle,
  Package,
  Users,
  Zap,
  BarChart2,
  RefreshCw
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  Cell
} from 'recharts';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

export default function PricingEngine() {
  const { products, pricingRules, togglePricingRule, updateProductPrice } = useStore();
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [simulationMode, setSimulationMode] = useState(false);

  

  // Demand vs Price scatter
  const demandPriceData = useMemo(() => {
    return products.map(p => ({
      x: p.demandScore * 100,
      y: (p.dynamicPrice - p.basePrice) / p.basePrice * 100,
      name: p.name,
      category: p.category,
    }));
  }, [products]);

  const priceStats = useMemo(() => {
    const increases = products.filter(p => p.dynamicPrice > p.basePrice).length;
    const decreases = products.filter(p => p.dynamicPrice < p.basePrice).length;
    const unchanged = products.filter(p => p.dynamicPrice === p.basePrice).length;
    const avgChange = products.reduce((sum, p) => 
      sum + (p.dynamicPrice - p.basePrice) / p.basePrice * 100, 0
    ) / products.length;

    return { increases, decreases, unchanged, avgChange };
  }, [products]);

  const handlePriceSimulation = (productId: string, multiplier: number) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      const newPrice = Math.round(product.basePrice * multiplier * 100) / 100;
      updateProductPrice(productId, newPrice);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Dynamic Pricing Engine</h1>
          <p className="text-slate-500">Real-time demand-responsive pricing with business rules</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSimulationMode(!simulationMode)}
            className={cn(
              'flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors',
              simulationMode
                ? 'bg-amber-100 text-amber-700'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            )}
          >
            <RefreshCw className={cn('h-4 w-4', simulationMode && 'animate-spin')} />
            <span>{simulationMode ? 'Simulation Mode' : 'Live Mode'}</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{priceStats.increases}</p>
              <p className="text-xs text-slate-500">Price Increases</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-100 rounded-lg">
              <TrendingDown className="h-5 w-5 text-red-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{priceStats.decreases}</p>
              <p className="text-xs text-slate-500">Price Decreases</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-slate-100 rounded-lg">
              <DollarSign className="h-5 w-5 text-slate-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{priceStats.unchanged}</p>
              <p className="text-xs text-slate-500">Unchanged</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <BarChart2 className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <p className={cn(
                'text-2xl font-bold',
                priceStats.avgChange > 0 ? 'text-green-600' : priceStats.avgChange < 0 ? 'text-red-500' : 'text-slate-800'
              )}>
                {priceStats.avgChange > 0 ? '+' : ''}{priceStats.avgChange.toFixed(1)}%
              </p>
              <p className="text-xs text-slate-500">Avg Change</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pricing Rules */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">Pricing Rules</h2>
            <Settings className="h-4 w-4 text-slate-400" />
          </div>

          <div className="space-y-3">
            {pricingRules.map((rule) => (
              <div
                key={rule.id}
                className={cn(
                  'border rounded-lg p-3 transition-all',
                  rule.active ? 'border-indigo-200 bg-indigo-50' : 'border-slate-200'
                )}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium text-slate-800 text-sm">{rule.name}</h3>
                      <span className={cn(
                        'text-xs px-1.5 py-0.5 rounded',
                        rule.type === 'demand' ? 'bg-amber-100 text-amber-700' :
                        rule.type === 'inventory' ? 'bg-blue-100 text-blue-700' :
                        rule.type === 'competition' ? 'bg-purple-100 text-purple-700' :
                        rule.type === 'segment' ? 'bg-green-100 text-green-700' :
                        'bg-slate-100 text-slate-700'
                      )}>
                        {rule.type}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1 font-mono">{rule.condition}</p>
                    <div className="flex items-center space-x-3 mt-2 text-xs text-slate-600">
                      <span className={rule.adjustment > 0 ? 'text-green-600' : 'text-red-500'}>
                        {rule.adjustment > 0 ? '+' : ''}{rule.adjustment}%
                      </span>
                      <span>Min Margin: {(rule.minMargin * 100).toFixed(0)}%</span>
                      <span>Max Discount: {(rule.maxDiscount * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                  <button
                    onClick={() => togglePricingRule(rule.id)}
                    className={cn(
                      'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                      rule.active ? 'bg-indigo-600' : 'bg-slate-300'
                    )}
                  >
                    <span
                      className={cn(
                        'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                        rule.active ? 'translate-x-6' : 'translate-x-1'
                      )}
                    />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Business Constraints */}
          <div className="mt-6 pt-4 border-t border-slate-200">
            <h3 className="text-sm font-medium text-slate-700 mb-3">Business Constraints</h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-600">Minimum Margin</span>
                <span className="font-medium text-slate-800">15%</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-600">Maximum Discount</span>
                <span className="font-medium text-slate-800">20%</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-600">Price Parity</span>
                <span className="flex items-center text-green-600">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Enabled
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Price vs Demand Scatter */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Demand vs Price Adjustment</h2>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="x"
                name="Demand Score"
                tick={{ fontSize: 10 }}
                stroke="#94a3b8"
                label={{ value: 'Demand (%)', position: 'bottom', fontSize: 10 }}
              />
              <YAxis
                dataKey="y"
                name="Price Change"
                tick={{ fontSize: 10 }}
                stroke="#94a3b8"
                label={{ value: 'Price Change (%)', angle: -90, position: 'left', fontSize: 10 }}
              />
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: 12 }}
                formatter={(value, name) => [
                  name === 'x' ? `${Number(value).toFixed(0)}%` : `${Number(value).toFixed(1)}%`,
                  name === 'x' ? 'Demand' : 'Price Δ'
                ]}
              />
              <Scatter data={demandPriceData} fill="#6366f1">
                {demandPriceData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.y > 0 ? '#10b981' : entry.y < 0 ? '#ef4444' : '#94a3b8'}
                  />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
          <p className="text-xs text-slate-500 mt-2 text-center">
            Each point represents a product. Color indicates price direction.
          </p>
        </div>

        {/* Product Simulator */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Price Simulator</h2>
          
          <div className="mb-4">
            <label className="block text-sm text-slate-600 mb-2">Select Product</label>
            <select
              value={selectedProduct?.id || ''}
              onChange={(e) => setSelectedProduct(products.find(p => p.id === e.target.value) || null)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Choose a product...</option>
              {products.slice(0, 20).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          {selectedProduct && (
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                <span className="text-3xl">{selectedProduct.imageUrl}</span>
                <div>
                  <p className="font-medium text-slate-800">{selectedProduct.name}</p>
                  <p className="text-xs text-slate-500">{selectedProduct.category}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-2 bg-slate-50 rounded-lg">
                  <p className="text-slate-500 text-xs">Base Price</p>
                  <p className="font-semibold text-slate-800">${selectedProduct.basePrice.toFixed(2)}</p>
                </div>
                <div className="p-2 bg-indigo-50 rounded-lg">
                  <p className="text-indigo-600 text-xs">Dynamic Price</p>
                  <p className="font-semibold text-indigo-700">${selectedProduct.dynamicPrice.toFixed(2)}</p>
                </div>
                <div className="p-2 bg-slate-50 rounded-lg">
                  <p className="text-slate-500 text-xs flex items-center">
                    <Zap className="h-3 w-3 mr-1" />
                    Demand Score
                  </p>
                  <p className="font-semibold text-slate-800">{(selectedProduct.demandScore * 100).toFixed(0)}%</p>
                </div>
                <div className="p-2 bg-slate-50 rounded-lg">
                  <p className="text-slate-500 text-xs flex items-center">
                    <Package className="h-3 w-3 mr-1" />
                    Inventory
                  </p>
                  <p className="font-semibold text-slate-800">{selectedProduct.inventory}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-slate-600 mb-2">Competitor Prices</p>
                <div className="flex space-x-2">
                  {selectedProduct.competitorPrices.map((price, i) => (
                    <span key={i} className="px-2 py-1 bg-slate-100 rounded text-xs font-medium text-slate-700">
                      ${price.toFixed(2)}
                    </span>
                  ))}
                </div>
              </div>

              {simulationMode && (
                <div className="pt-3 border-t border-slate-200">
                  <p className="text-sm text-slate-600 mb-2">Simulate Price Change</p>
                  <div className="flex space-x-2">
                    {[0.9, 0.95, 1.0, 1.05, 1.1].map((mult) => (
                      <button
                        key={mult}
                        onClick={() => handlePriceSimulation(selectedProduct.id, mult)}
                        className={cn(
                          'px-3 py-1 rounded text-xs font-medium transition-colors',
                          mult === 1 ? 'bg-slate-200 text-slate-700' :
                          mult < 1 ? 'bg-red-100 text-red-700 hover:bg-red-200' :
                          'bg-green-100 text-green-700 hover:bg-green-200'
                        )}
                      >
                        {mult < 1 ? '' : '+'}{((mult - 1) * 100).toFixed(0)}%
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {!selectedProduct && (
            <div className="text-center py-8 text-slate-400">
              <DollarSign className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Select a product to simulate pricing</p>
            </div>
          )}
        </div>
      </div>

      {/* Price Change Timeline */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="font-semibold text-slate-800 mb-4">Price Distribution by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {['Electronics', 'Fashion', 'Home & Garden', 'Sports & Outdoors', 'Beauty & Health'].map((cat) => {
            const catProducts = products.filter(p => p.category === cat);
            const avgDiff = catProducts.reduce((sum, p) => 
              sum + (p.dynamicPrice - p.basePrice) / p.basePrice * 100, 0
            ) / catProducts.length;

            return (
              <div key={cat} className="p-4 bg-slate-50 rounded-lg">
                <p className="text-sm font-medium text-slate-700 mb-2">{cat}</p>
                <p className={cn(
                  'text-2xl font-bold',
                  avgDiff > 0 ? 'text-green-600' : avgDiff < 0 ? 'text-red-500' : 'text-slate-800'
                )}>
                  {avgDiff > 0 ? '+' : ''}{avgDiff.toFixed(1)}%
                </p>
                <p className="text-xs text-slate-500">{catProducts.length} products</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Algorithm Explanation */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 text-white">
        <h2 className="font-semibold mb-4">Pricing Algorithm Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white/10 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Zap className="h-5 w-5 text-amber-400" />
              <h3 className="font-medium">Demand Velocity</h3>
            </div>
            <p className="text-sm text-slate-300">
              Real-time tracking of view and purchase velocity to detect demand spikes
            </p>
          </div>
          <div className="p-4 bg-white/10 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <BarChart2 className="h-5 w-5 text-purple-400" />
              <h3 className="font-medium">Competitor Analysis</h3>
            </div>
            <p className="text-sm text-slate-300">
              Continuous monitoring of competitor prices with automated response rules
            </p>
          </div>
          <div className="p-4 bg-white/10 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Package className="h-5 w-5 text-blue-400" />
              <h3 className="font-medium">Inventory Signals</h3>
            </div>
            <p className="text-sm text-slate-300">
              Price adjustments based on stock levels and restock timelines
            </p>
          </div>
          <div className="p-4 bg-white/10 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Users className="h-5 w-5 text-green-400" />
              <h3 className="font-medium">Segment WTP</h3>
            </div>
            <p className="text-sm text-slate-300">
              ML-estimated willingness-to-pay by user segment (fairness-constrained)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
