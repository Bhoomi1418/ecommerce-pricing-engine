import { useState } from 'react';
import {
  FlaskConical,
  Play,
  Pause,
  CheckCircle,
  TrendingUp,
  Users,
  DollarSign,
  Target,
  BarChart2,
  Plus,
  Calendar
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { useStore } from '../../store/useStore';
import { ABTest } from '../../types';
import { cn } from '../../utils/cn';

export default function ABTesting() {
  const { abTests, updateABTestStatus } = useStore();
  const [selectedTest, setSelectedTest] = useState<ABTest | null>(abTests[0] || null);
  const [showNewTestModal, setShowNewTestModal] = useState(false);

  const getStatusBadge = (status: ABTest['status']) => {
    switch (status) {
      case 'running':
        return (
          <span className="flex items-center space-x-1 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
            <Play className="h-3 w-3" />
            <span>Running</span>
          </span>
        );
      case 'paused':
        return (
          <span className="flex items-center space-x-1 text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full">
            <Pause className="h-3 w-3" />
            <span>Paused</span>
          </span>
        );
      case 'completed':
        return (
          <span className="flex items-center space-x-1 text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
            <CheckCircle className="h-3 w-3" />
            <span>Completed</span>
          </span>
        );
    }
  };

  const calculateUplift = (control: number, treatment: number) => {
    return ((treatment - control) / control * 100).toFixed(1);
  };

  const generateTimeSeriesData = (test: ABTest) => {
    const days = 7;
    return Array.from({ length: days }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (days - 1 - i));
      const controlBase = test.variants[0].results.conversions / days;
      const treatmentBase = test.variants[1]?.results.conversions / days || controlBase;
      
      return {
        date: date.toLocaleDateString('en-US', { weekday: 'short' }),
        control: Math.round(controlBase * (0.8 + Math.random() * 0.4)),
        treatment: Math.round(treatmentBase * (0.8 + Math.random() * 0.4)),
      };
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">A/B Testing Framework</h1>
          <p className="text-slate-500">Statistical experimentation for pricing and recommendations</p>
        </div>
        <button
          onClick={() => setShowNewTestModal(true)}
          className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>New Experiment</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Test List */}
        <div className="space-y-4">
          <h2 className="font-semibold text-slate-700">Active Experiments</h2>
          {abTests.map((test) => (
            <div
              key={test.id}
              onClick={() => setSelectedTest(test)}
              className={cn(
                'bg-white rounded-xl border p-4 cursor-pointer transition-all',
                selectedTest?.id === test.id
                  ? 'border-indigo-500 shadow-md'
                  : 'border-slate-200 hover:border-slate-300'
              )}
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-medium text-slate-800">{test.name}</h3>
                {getStatusBadge(test.status)}
              </div>
              <p className="text-sm text-slate-500 mb-3">{test.description}</p>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>{new Date(test.startDate).toLocaleDateString()}</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Users className="h-3 w-3" />
                  <span>{test.metrics.totalVisitors.toLocaleString()}</span>
                </span>
              </div>
              {test.metrics.winner && (
                <div className="mt-3 p-2 bg-green-50 rounded-lg text-xs text-green-700 flex items-center space-x-1">
                  <CheckCircle className="h-3 w-3" />
                  <span>Winner: {test.variants.find(v => v.id === test.metrics.winner)?.name}</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Test Details */}
        {selectedTest && (
          <div className="lg:col-span-2 space-y-6">
            {/* Test Overview */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-800">{selectedTest.name}</h2>
                  <p className="text-slate-500">{selectedTest.description}</p>
                </div>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(selectedTest.status)}
                  {selectedTest.status === 'running' && (
                    <button
                      onClick={() => updateABTestStatus(selectedTest.id, 'paused')}
                      className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
                    >
                      <Pause className="h-4 w-4 text-slate-600" />
                    </button>
                  )}
                  {selectedTest.status === 'paused' && (
                    <button
                      onClick={() => updateABTestStatus(selectedTest.id, 'running')}
                      className="p-2 rounded-lg bg-green-100 hover:bg-green-200 transition-colors"
                    >
                      <Play className="h-4 w-4 text-green-600" />
                    </button>
                  )}
                </div>
              </div>

              {/* Statistical Summary */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">Total Visitors</p>
                  <p className="text-xl font-bold text-slate-800">
                    {selectedTest.metrics.totalVisitors.toLocaleString()}
                  </p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">Total Conversions</p>
                  <p className="text-xl font-bold text-slate-800">
                    {selectedTest.metrics.totalConversions.toLocaleString()}
                  </p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">Total Revenue</p>
                  <p className="text-xl font-bold text-slate-800">
                    ${selectedTest.metrics.totalRevenue.toLocaleString()}
                  </p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">Statistical Significance</p>
                  <p className={cn(
                    'text-xl font-bold',
                    selectedTest.metrics.statisticalSignificance >= 0.95
                      ? 'text-green-600'
                      : selectedTest.metrics.statisticalSignificance >= 0.90
                      ? 'text-amber-600'
                      : 'text-slate-800'
                  )}>
                    {(selectedTest.metrics.statisticalSignificance * 100).toFixed(0)}%
                  </p>
                </div>
              </div>

              {/* Variants Comparison */}
              <div className="space-y-4">
                {selectedTest.variants.map((variant, index) => (
                  <div
                    key={variant.id}
                    className={cn(
                      'border rounded-xl p-4',
                      selectedTest.metrics.winner === variant.id
                        ? 'border-green-300 bg-green-50'
                        : 'border-slate-200'
                    )}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className={cn(
                          'px-2 py-0.5 rounded text-xs font-medium',
                          index === 0 ? 'bg-slate-200 text-slate-700' : 'bg-indigo-100 text-indigo-700'
                        )}>
                          {index === 0 ? 'Control' : 'Treatment'}
                        </span>
                        <h3 className="font-medium text-slate-800">{variant.name}</h3>
                        {selectedTest.metrics.winner === variant.id && (
                          <span className="flex items-center space-x-1 text-xs text-green-600">
                            <CheckCircle className="h-3 w-3" />
                            <span>Winner</span>
                          </span>
                        )}
                      </div>
                      <span className="text-sm text-slate-500">{variant.trafficPercentage}% traffic</span>
                    </div>

                    <div className="grid grid-cols-5 gap-4 text-sm">
                      <div>
                        <p className="text-slate-500 mb-1 flex items-center space-x-1">
                          <Users className="h-3 w-3" />
                          <span>Visitors</span>
                        </p>
                        <p className="font-semibold text-slate-800">
                          {variant.results.visitors.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500 mb-1 flex items-center space-x-1">
                          <Target className="h-3 w-3" />
                          <span>Conv. Rate</span>
                        </p>
                        <p className="font-semibold text-slate-800">
                          {variant.results.conversionRate.toFixed(1)}%
                          {index > 0 && (
                            <span className={cn(
                              'ml-1 text-xs',
                              variant.results.conversionRate > selectedTest.variants[0].results.conversionRate
                                ? 'text-green-600'
                                : 'text-red-500'
                            )}>
                              ({calculateUplift(
                                selectedTest.variants[0].results.conversionRate,
                                variant.results.conversionRate
                              )}%)
                            </span>
                          )}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500 mb-1 flex items-center space-x-1">
                          <DollarSign className="h-3 w-3" />
                          <span>Revenue</span>
                        </p>
                        <p className="font-semibold text-slate-800">
                          ${variant.results.revenue.toLocaleString()}
                          {index > 0 && (
                            <span className={cn(
                              'ml-1 text-xs',
                              variant.results.revenue > selectedTest.variants[0].results.revenue
                                ? 'text-green-600'
                                : 'text-red-500'
                            )}>
                              ({calculateUplift(
                                selectedTest.variants[0].results.revenue,
                                variant.results.revenue
                              )}%)
                            </span>
                          )}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500 mb-1 flex items-center space-x-1">
                          <BarChart2 className="h-3 w-3" />
                          <span>AOV</span>
                        </p>
                        <p className="font-semibold text-slate-800">
                          ${variant.results.avgOrderValue.toFixed(2)}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500 mb-1 flex items-center space-x-1">
                          <TrendingUp className="h-3 w-3" />
                          <span>RPS</span>
                        </p>
                        <p className="font-semibold text-slate-800">
                          ${variant.results.revenuePerSession.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {/* Confidence Interval */}
                    <div className="mt-3 pt-3 border-t border-slate-200">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500">Confidence: {(variant.results.confidence * 100).toFixed(0)}%</span>
                        <div className="w-48 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-indigo-500 rounded-full"
                            style={{ width: `${variant.results.confidence * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Time Series Chart */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="font-semibold text-slate-800 mb-4">Conversion Trend</h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={generateTimeSeriesData(selectedTest)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                  />
                  <Line type="monotone" dataKey="control" stroke="#94a3b8" strokeWidth={2} dot={{ r: 4 }} name="Control" />
                  <Line type="monotone" dataKey="treatment" stroke="#6366f1" strokeWidth={2} dot={{ r: 4 }} name="Treatment" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Statistical Validity */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-6">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <FlaskConical className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800">Statistical Analysis</h3>
                  <p className="text-sm text-slate-600 mt-1">
                    {selectedTest.metrics.statisticalSignificance >= 0.95 ? (
                      <>
                        <span className="text-green-600 font-medium">Results are statistically significant.</span>{' '}
                        We can be {(selectedTest.metrics.statisticalSignificance * 100).toFixed(0)}% confident that the 
                        observed difference is not due to random chance.
                      </>
                    ) : selectedTest.metrics.statisticalSignificance >= 0.90 ? (
                      <>
                        <span className="text-amber-600 font-medium">Results are approaching significance.</span>{' '}
                        Current confidence is {(selectedTest.metrics.statisticalSignificance * 100).toFixed(0)}%. 
                        Continue the test to reach 95% confidence.
                      </>
                    ) : (
                      <>
                        <span className="text-slate-600 font-medium">Collecting more data.</span>{' '}
                        Current confidence is {(selectedTest.metrics.statisticalSignificance * 100).toFixed(0)}%. 
                        More samples needed for statistical significance.
                      </>
                    )}
                  </p>
                  <div className="mt-3 grid grid-cols-3 gap-4 text-xs">
                    <div>
                      <span className="text-slate-500">Sample Size</span>
                      <p className="font-medium text-slate-700 mt-0.5">
                        {selectedTest.metrics.totalVisitors.toLocaleString()} users
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-500">Test Duration</span>
                      <p className="font-medium text-slate-700 mt-0.5">
                        {Math.floor((Date.now() - new Date(selectedTest.startDate).getTime()) / (1000 * 60 * 60 * 24))} days
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-500">MDE Detected</span>
                      <p className="font-medium text-slate-700 mt-0.5">
                        {selectedTest.variants[1] ? calculateUplift(
                          selectedTest.variants[0].results.conversionRate,
                          selectedTest.variants[1].results.conversionRate
                        ) : '0'}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* New Test Modal */}
      {showNewTestModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-lg w-full mx-4">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Create New Experiment</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Experiment Name</label>
                <input
                  type="text"
                  placeholder="e.g., Dynamic Pricing v3"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                <textarea
                  placeholder="Describe your hypothesis..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={3}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Target Metric</label>
                <select className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option>Conversion Rate</option>
                  <option>Revenue</option>
                  <option>Average Order Value</option>
                  <option>Revenue per Session</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Traffic Allocation</label>
                <input
                  type="range"
                  min="10"
                  max="100"
                  defaultValue="50"
                  className="w-full"
                />
                <p className="text-xs text-slate-500 mt-1">50% of eligible traffic</p>
              </div>
            </div>
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowNewTestModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowNewTestModal(false)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Create Experiment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
